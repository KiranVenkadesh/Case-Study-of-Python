import pandas as pd # type: ignore
import numpy as np # type: ignore
from sklearn.model_selection import train_test_split # type: ignore
from sklearn.preprocessing import StandardScaler # type: ignore
from sklearn.ensemble import RandomForestClassifier # type: ignore
from imblearn.over_sampling import SMOTE  # type: ignore
import joblib # type: ignore

# Step 1: Load the data
df = pd.read_csv("D:/Data Science/Project/loan_data.csv")

# Step 2: Define numerical and categorical features
num_features = ['person_age', 'person_income', 'person_emp_exp', 'loan_amnt', 'loan_int_rate',
                'loan_percent_income', 'cb_person_cred_hist_length', 'credit_score']

cat_features = ['person_gender', 'person_education', 'person_home_ownership',
                'loan_intent', 'previous_loan_defaults_on_file']

# Step 3: Remove outliers using IQR method
for col in num_features:
    q1 = df[col].quantile(0.25)
    q3 = df[col].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr
    df = df[(df[col] >= lower_bound) & (df[col] <= upper_bound)]

# Step 4: Split data into features and target
X = df.drop(columns=['loan_status'])
y = df['loan_status']

# Step 5: Train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Step 6: Scale numerical features
scaler = StandardScaler()
X_train[num_features] = scaler.fit_transform(X_train[num_features])
X_test[num_features] = scaler.transform(X_test[num_features])

# Step 7: One-hot encode categorical features
X_train = pd.get_dummies(X_train, columns=cat_features, drop_first=True)
X_test = pd.get_dummies(X_test, columns=cat_features, drop_first=True)

# Step 8: Drop irrelevant education columns (based on feature importance)
columns_to_drop = [
    'person_education_Bachelor',
    'person_education_Master',
    'person_education_Doctorate',
    'person_education_High School'
]

X_train.drop(columns=[col for col in columns_to_drop if col in X_train.columns], inplace=True)
X_test.drop(columns=[col for col in columns_to_drop if col in X_test.columns], inplace=True)

# Step 9: Align train and test sets
X_train, X_test = X_train.align(X_test, join='left', axis=1, fill_value=0)

# Step 10: Balance the training set using SMOTE
smote = SMOTE(random_state=42)
X_train, y_train = smote.fit_resample(X_train, y_train)

# Step 11: Train the Random Forest model
model = RandomForestClassifier(random_state=42, n_jobs=-1)
model.fit(X_train, y_train)

# Step 12: Save the model and features
joblib.dump(model, 'loan_default_model_v2.pkl')
# joblib.dump(X_train.columns.tolist(), 'model_features.pkl')  # save feature list for prediction phase
# joblib.dump(scaler, 'scaler.pkl')  # optionally save scaler if needed later

print("✅ Model and features saved successfully.")
